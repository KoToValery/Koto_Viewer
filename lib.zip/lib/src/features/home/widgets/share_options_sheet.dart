import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../../core/services/native_share_service.dart';

class ShareOptionsSheet extends StatelessWidget {
  final String filePath;

  const ShareOptionsSheet({
    super.key,
    required this.filePath,
  });

  Future<void> _shareViaEmail(BuildContext context) async {
    Navigator.pop(context);
    
    final success = await NativeShareService.shareViaEmail(filePath);
    
    if (!success && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Грешка при споделяне по Email'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _shareViaMessaging(BuildContext context) async {
    Navigator.pop(context);
    
    final success = await NativeShareService.shareViaMessaging(filePath);
    
    if (!success && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Грешка при споделяне по съобщения'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _shareViaCloud(BuildContext context) async {
    Navigator.pop(context);
    
    final success = await NativeShareService.shareViaCloud(filePath);
    
    if (!success && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Грешка при качване в облак'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _shareWithAll(BuildContext context) async {
    Navigator.pop(context);
    
    try {
      await Share.shareXFiles(
        [XFile(filePath)],
        subject: 'PDF Document',
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Грешка при споделяне: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final fileName = filePath.split(Platform.pathSeparator).last;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle bar
          Container(
            width: 40,
            height: 4,
            margin: const EdgeInsets.only(bottom: 20),
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Title
          Text(
            'Изпрати PDF документ',
            style: theme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            fileName,
            style: theme.textTheme.bodySmall?.copyWith(
              color: Colors.grey.shade600,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 24),

          // Email Option
          _ShareOptionTile(
            icon: Icons.email_outlined,
            iconColor: Colors.blue,
            title: 'Изпрати по Email',
            subtitle: 'Gmail, Outlook и други',
            onTap: () => _shareViaEmail(context),
          ),

          const SizedBox(height: 12),

          // Messaging Option
          _ShareOptionTile(
            icon: Icons.chat_bubble_outline,
            iconColor: Colors.green,
            title: 'Изпрати по съобщение',
            subtitle: 'Viber, WhatsApp, Messenger',
            onTap: () => _shareViaMessaging(context),
          ),

          const SizedBox(height: 12),

          // Cloud Option
          _ShareOptionTile(
            icon: Icons.cloud_upload_outlined,
            iconColor: Colors.orange,
            title: 'Качи в облак',
            subtitle: 'Google Drive, Dropbox, OneDrive',
            onTap: () => _shareViaCloud(context),
          ),

          const SizedBox(height: 20),

          const Divider(),

          const SizedBox(height: 12),

          // Show All Options
          TextButton.icon(
            icon: const Icon(Icons.more_horiz),
            label: const Text('Покажи всички опции'),
            style: TextButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            ),
            onPressed: () => _shareWithAll(context),
          ),

          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

class _ShareOptionTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ShareOptionTile({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: iconColor.withOpacity(0.1),
                child: Icon(icon, color: iconColor, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey.shade400),
            ],
          ),
        ),
      ),
    );
  }
}
